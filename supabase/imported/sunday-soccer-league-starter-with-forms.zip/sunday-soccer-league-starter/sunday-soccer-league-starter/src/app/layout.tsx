import type { ReactNode } from "react";

export const metadata = {
  title: "Sunday Soccer League",
  description: "Matchday recording system for a Sunday soccer league",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
