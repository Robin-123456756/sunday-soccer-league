export default function HomePage() {
  return (
    <main style={{ padding: 24, fontFamily: "Arial, sans-serif" }}>
      <h1>Sunday Soccer League Starter</h1>
      <p>This is the foundation project for matchday records, uploads, reports, and exports.</p>
    </main>
  );
}
