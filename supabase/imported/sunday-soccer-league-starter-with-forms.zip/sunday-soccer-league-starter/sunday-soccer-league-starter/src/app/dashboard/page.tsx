export default function DashboardPage() {
  return (
    <main style={{ padding: 24, fontFamily: "Arial, sans-serif" }}>
      <h1>Sunday Soccer League Dashboard</h1>
      <p>Use this dashboard to review fixtures, pending reports, recent incidents, and exports.</p>
    </main>
  );
}
