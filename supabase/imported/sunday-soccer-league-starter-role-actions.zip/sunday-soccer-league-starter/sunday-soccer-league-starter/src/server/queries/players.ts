import { createServerSupabaseClient } from "@/lib/supabase/server";
import type { ExportPlayerFilters } from "@/types/database";
import type { PlayerExportRow } from "@/types/player";

export async function getExportablePlayerRows(filters: ExportPlayerFilters = {}): Promise<PlayerExportRow[]> {
  const supabase = await createServerSupabaseClient();

  let query = supabase
    .from("players")
    .select(`
      id,
      full_name,
      jersey_number,
      position,
      registration_number,
      is_active,
      teams(name),
      card_events(card_type),
      match_lineups(id)
    `)
    .order("full_name", { ascending: true });

  if (filters.teamId) {
    query = query.eq("team_id", filters.teamId);
  }

  if (filters.playerId) {
    query = query.eq("id", filters.playerId);
  }

  const { data, error } = await query;

  if (error) {
    throw new Error("Could not load player export data.");
  }

  return (data ?? []).map((player: any) => {
    const cardEvents = Array.isArray(player.card_events) ? player.card_events : [];
    const lineups = Array.isArray(player.match_lineups) ? player.match_lineups : [];

    return {
      fullName: player.full_name,
      teamName: player.teams?.name ?? "",
      jerseyNumber: player.jersey_number ?? "",
      position: player.position ?? "",
      registrationNumber: player.registration_number ?? "",
      isActive: player.is_active,
      yellowCards: cardEvents.filter((event: any) => event.card_type === "yellow").length,
      redCards: cardEvents.filter((event: any) => event.card_type !== "yellow").length,
      appearances: lineups.length,
    } satisfies PlayerExportRow;
  });
}
