import { createServerSupabaseClient } from "@/lib/supabase/server";
import type { MatchRecord } from "@/types/database";

export async function getMatchById(matchId: string): Promise<MatchRecord> {
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("matches")
    .select("*")
    .eq("id", matchId)
    .single();

  if (error || !data) {
    throw new Error("Match not found.");
  }

  return data as MatchRecord;
}

export async function getAssignedRefereeMatchIds() {
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("matches")
    .select("id")
    .order("match_date", { ascending: false });

  if (error) {
    throw new Error("Could not load referee matches.");
  }

  return (data ?? []).map((row) => row.id as string);
}
