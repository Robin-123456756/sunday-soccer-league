export default function MatchesPage() {
  return (
    <main style={{ padding: 24, fontFamily: "Arial, sans-serif" }}>
      <h1>Matches</h1>
      <p>List, filter, and manage league fixtures here.</p>
    </main>
  );
}
