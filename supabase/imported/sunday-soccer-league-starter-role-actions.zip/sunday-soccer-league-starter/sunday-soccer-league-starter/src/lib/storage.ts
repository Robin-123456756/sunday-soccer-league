export interface UploadFileInput {
  matchId: string;
  teamId: string;
  file: File;
}

export interface StoredFileMeta {
  fileName: string;
  fileUrl: string;
  fileType: string;
  storagePath: string;
}

const ALLOWED_MIME_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "application/pdf",
];

export function validateTeamSheetFile(file: File): void {
  if (!ALLOWED_MIME_TYPES.includes(file.type)) {
    throw new Error("Only JPG, PNG, WEBP, and PDF team sheet files are allowed.");
  }
}

export function buildTeamSheetStoragePath(params: {
  season: string;
  matchId: string;
  teamId: string;
  fileName: string;
}): string {
  const safeName = params.fileName.replace(/\s+/g, "-").toLowerCase();
  return `team-sheets/${params.season}/${params.matchId}/${params.teamId}/${safeName}`;
}

export async function uploadTeamSheet(_input: UploadFileInput): Promise<StoredFileMeta> {
  throw new Error("Implement this function with Supabase Storage or your chosen file storage provider.");
}
